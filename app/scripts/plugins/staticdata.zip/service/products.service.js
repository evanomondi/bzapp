(function () {

    'use strict';

    angular.module('app.plugin.service').factory('productsService', ProductsService);

    ProductsService.$inject = ['$http', '$q', 'PluginContext', 'Product', 'productAdapter', 'productDetailsAdapter'];

    function ProductsService($http, $q, PluginContext, Product, productAdapter, productDetailsAdapter) {

        return {
            getProductsForCategory: getProductsForCategory,
            getProductDetails: getProductDetails,
            findProducts: findProducts,
        };

        function getProductsForCategory(categoryId) {
            return findProducts({
                category: categoryId
            });
        }

        function findProducts(options) {
            var categoryId = options.storeCategoryId || '',
                title = options.key || '',
                url = PluginContext.DATA_PATH + '/products/' + (categoryId ? categoryId + 'Products.json' : 'allProducts.json'),
                params = {
                    title: title,
                    limit: options.pageSize,
                    page: (typeof options.page === 'number') ? options.page : 0,
                    order: options.sort,
                    ids: options.ids
                };

            cleanParams(params);

            return $http.get(url).then(function (result) {
                return processProducts(result.data, params);
            }, function () {
                return [];
            });
        }

        function getProductDetails(productId) {
            return findProducts({ids: productId}).then(function (products) {
                return products.length ? products[0] : null;          
            });            
        }

        function processProducts(products, options) {
            var newProducts = products.map(processProduct),
                limit = options.limit,
                page = options.page || 0,
                ids = options.ids ? options.ids.split(',') : null;

            if (ids) {
                newProducts = newProducts.filter(function (product) {
                    var matchesId = false;
                    for(var i=0; i<ids.length; i++) {
                        if (product.id.toString() === ids[i]) {
                            matchesId = true;
                            break;
                        }
                    }

                    return matchesId;                    
                });
            } else {
                if (options.title) {
                    newProducts = newProducts.filter(function (product) {
                        return !!product.title.match(new RegExp(options.title, 'i'));
                    });
                }

                if (options.order) {
                    // perform sorting
                    newProducts = sortProducts(newProducts, getSortOptionsById(PluginContext.SORTING_OPTIONS, options.order).value);
                }

                if (limit) {
                    newProducts = newProducts.slice(page * limit, page * limit + limit);
                }
            }

            return newProducts;
        }

        function processProduct(product) {
            var newProduct = Product.build(product, productDetailsAdapter);
            return newProduct;
        }

        function sortProducts(products, sortValue) {
            var sortValueParts,
                direction = 1,
                sortField;

            if (sortValue) {

                sortValueParts = sortValue.split('+');

                sortField = sortValueParts[0];

                // sort direction is specified
                if (sortValueParts.length === 2) {
                    direction = (sortValueParts[1] === 'asc') ? 1 : -1;
                }

                try {
                    products = products.sort(function (a, b) {
                        if (a[sortField] > b[sortField]) {
                            return direction;
                        } else {
                            return -direction;
                        }
                    });
                } catch (e) {
                    console.log('Error while sorting: ' + e);
                }
            }

            return products;
        }

        function getSortOptionsById(options, id) {
            var filteredOptions = options.filter(function (option) {
                return option.id === id;
            });

            if (filteredOptions.length) {
                return filteredOptions[0];
            } else {
                return null;
            }
        }

        function cleanParams(params) {
            for (var key in params) {
                if (params.hasOwnProperty(key)) {
                    //Now, object[key] is the current value
                    if (params[key] === null || params[key] === '') {
                        delete params[key];
                    }
                }
            }
        }
    }

})();