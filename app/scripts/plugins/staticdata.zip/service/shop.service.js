(function () {

    'use strict';

    angular.module('app.plugin.service').factory('shopService', shopService);

    shopService.$inject = ['$http', 'PluginContext', 'Shop', 'shopAdapter'];

    function shopService($http, PluginContext, Shop, shopAdapter) {

        return {
            getShopData: getShopData
        };

        function getShopData() {
            var url = PluginContext.DATA_PATH + '/getShopData.json';

            return $http.get(url).then(function (result) {
            	return Shop.build(result.data, shopAdapter);
            });
        }

    }

})();