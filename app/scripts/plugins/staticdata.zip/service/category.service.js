(function () {

    'use strict';

    angular.module('app.plugin.service')
        .factory('categoryService', CategoryService);


    CategoryService.$inject = ['$q', '$http', 'PluginContext', 'NavTree', 'navTreeAdapter', 'Category', 'categoryAdapter'];

    function CategoryService($q, $http, PluginContext, NavTree, navTreeAdapter, Category, categoryAdapter) {

        return {
            getNavTree: getNavTree,
            getCategoryById: getCategoryById
        };

        function getNavTree() {
            var url = PluginContext.DATA_PATH + '/getNavigationLinks.json';

            return $http.get(url).then(function (result) {
                var tree = NavTree.build(result.data, navTreeAdapter);

                return tree;
            });
        }

        function getCategoryById(categoryId) {
            var url = PluginContext.DATA_PATH + '/getCategory' + categoryId + '.json';

            return $http.get(url).then(function (result) {
                return Category.build(result.data, categoryAdapter);
            });
        }
    }

})();