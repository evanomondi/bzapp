(function () {

    'use strict';

    angular.module('app.plugin.service').factory('shoppingCartService', ShoppingCartService);

    ShoppingCartService.$inject = ['$q', '$http', '$localStorage', 'AppContext', 'Cart', 'CartItem', 'cartAdapter', 'cartItemAdapter', 'productsService'];

    function ShoppingCartService($q, $http, $storage, AppContext, Cart, CartItem, cartAdapter, cartItemAdapter, productsService) {

        // deserialize to Cart model        
        $storage.cart = $storage.cart ? Cart.build($storage.cart) : null;

        return {
            getCart: getCart,
            addProduct: addProduct,
            removeItem: removeItem,
            changeItem: changeItem,
            requestCheckout: requestCheckout
        };

        function getCart() {
            if (!$storage.cart) {
                $storage.cart = Cart.build({
                    id: 'mycartid',
                    total: 0,
                    items: []
                }, cartAdapter);
            } else {
                calclateCartTotal();
            }

            return $q.when($storage.cart);
        }

        function addProduct(productId, variantId, quantity) {
            return productsService.findProducts({
                ids: productId.toString()
            }).then(function (products) {
                var product = products.length ? products[0] : null,
                    variantOptions = [],
                    cartItem,
                    variant;

                if (product) {
                    variant = getVariantById(product, variantId);
                    for (var key in variant.options) {
                        if (variant.options.hasOwnProperty(key)) {
                            variantOptions.push(variant.options[key]);
                        }
                    }

                    cartItem = getCartItemById(variantId);

                    // item is already in cart
                    if (cartItem) {
                        cartItem.quantity += quantity;

                    } else {
                        // new cart item
                        cartItem = CartItem.build({
                            id: variant.id,
                            title: product.title,
                            productId: productId,
                            variantId: variantId,
                            description: product.description,
                            price: variant.price,
                            salePrice: variant.salePrice,
                            sku: variant.sku,
                            quantity: quantity,
                            image: getImageById(variant.imageId, product),
                            options: variantOptions
                        }, cartItemAdapter);

                        $storage.cart.items.push(cartItem);
                    }

                    calclateCartTotal();

                    return $storage.cart;
                } else {
                    throw Error('Could not add product as such product does not exist');
                }
            });
        }

        function removeItem(id) {
            return changeItem(id, 0);
        }

        function changeItem(id, quantity) {
            var cartItem = getCartItemById(id);

            if (cartItem) {
                if (quantity > 0) {
                    cartItem.quantity = quantity;
                } else {
                    $storage.cart.items.splice($storage.cart.items.indexOf(cartItem), 1);
                }
            }

            calclateCartTotal();

            return $q.when($storage.cart);
        }

        function requestCheckout() {
            return $q.when(true);
        }

        function getVariantById(product, variantId) {
            var variants = product.variants.filter(function (variant) {
                return variant.id === variantId;
            });

            return variants.length ? variants[0] : null;
        }

        function getImageById(imageId, product) {
            var images = product.images.filter(function (image) {
                return image.id === imageId;
            });

            return images.length ? images[0].src : product.image;
        }

        function getCartItemById(id) {
            var item = null;
            if ($storage.cart) {
                item = $storage.cart.items.filter(function (i) {
                    return i.id === id;
                });

                item = item.length ? item[0] : null;
            }

            return item;
        }

        function calclateCartTotal() {
            var total = 0;
            $storage.cart.items.forEach(function (item) {
                total += item.quantity * parseFloat(item.price);
            });

            $storage.cart.total = total;

        }
    }

})();