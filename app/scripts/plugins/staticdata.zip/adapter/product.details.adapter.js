(function () {

    'use strict';

    angular.module('app.plugin.adapter').factory('productDetailsAdapter', adapter);

    adapter.$inject = ['Variant', 'ProductOption', 'variantAdapter', 'productOptionAdapter'];

    function adapter(Variant, ProductOption, variantAdapter, optionAdapter) {

        return {
            transform: function (destination, source) {
                if (source.hasOwnProperty('length')) {
                    source = source[0];
                }

                destination.id = source.id;
                destination.title = source.title;
                destination.shortDescription = source.shortDescription;
                destination.vendor = source.vendor;
                destination.image = source.image;
                destination.price = source.price;
                destination.salePrice = source.salePrice;
                destination.images = source.images;
                destination.isFullProduct = true;

                destination.options = source.options.map(function (option) {
                    return ProductOption.build(option, optionAdapter);
                });

                destination.optionsLayoutState = source.optionsLayoutState;

                destination.variants = source.variants.map(function (variant) {
                    return Variant.build(variant, variantAdapter);
                });
            }
        };
    }
})();