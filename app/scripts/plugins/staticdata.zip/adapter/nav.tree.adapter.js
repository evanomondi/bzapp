(function () {

    'use strict';

    angular.module('app.plugin.adapter').factory('navTreeAdapter', adapter);

    adapter.$inject = ['CategoryNav', 'categoryNavAdapter'];

    function adapter(CategoryNav, categoryNavAdapter) {

        return {
            transform: function (destination, source) {                    
                destination.categories = buildCategoryTree(source.categories);     
            }
        };    

        function buildCategoryTree(links) {
            /*var tree = [];
            links.forEach(function (link) {
                var category;
                if (link.parent === rootCategory) {
                    category = CategoryNav.build(link, categoryNavAdapter);
                    tree.push(category);
                    category.categories = buildCategoryTree(links, link.handle);
                }
            });

            return tree;*/           

            return links.map(function (link) {
                 var categoryNav = CategoryNav.build(link, categoryNavAdapter);
                 categoryNav.categories = buildCategoryTree(link.categories);
                 return categoryNav;
            });
        } 
    }

})();