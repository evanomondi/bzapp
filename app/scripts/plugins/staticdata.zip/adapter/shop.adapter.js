(function () {

    'use strict';

    angular.module('app.plugin.adapter').factory('shopAdapter', adapter);

    adapter.$inject = [];

    function adapter() {

        return {
            transform: function (destination, source) {
                destination.currency = source.currency;
                destination.rawData = source.rawData;
            }
        };       
    }

})();