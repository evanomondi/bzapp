(function () {

    'use strict';

    angular.module('app.plugin.adapter').factory('cartItemAdapter', adapter);

    adapter.$inject = [];

    function adapter() {

        return {
            transform: function (destination, source) {
                destination.id = source.id;
                destination.title = source.title;
                destination.productId = source.id;
                destination.variantId = source.id;
                destination.description = source.description;
                destination.price = source.price;
                destination.salePrice = source.salePrice;
                destination.sku = source.sku;
                destination.quantity = source.quantity;
                destination.image = source.image;
                destination.variantDescription = source.options.join(', ');
            }
        };
    }

})();