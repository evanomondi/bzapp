(function () {

    'use strict';

    angular.module('app.plugin.adapter').factory('cartAdapter', adapter);

    adapter.$inject = [];

    function adapter() {

        return {
            transform: function (destination, source) {
                destination.id = source.id;
                destination.total = source.total;
                destination.items = source.items;
            }
        };       
    }

})();