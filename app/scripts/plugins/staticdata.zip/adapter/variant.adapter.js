(function () {

    'use strict';

    angular.module('app.plugin.adapter').factory('variantAdapter', adapter);

    adapter.$inject = [];

    function adapter() {

        return {
            transform: function (destination, source) {
                destination.id = source.id;
                destination.title = source.title;
                destination.vendor = source.vendor;
                destination.imageId = source.imageId;
                destination.price = source.price;
                destination.salePrice = source.salePrice;
                destination.sku = source.sku;
                destination.productId = source.productId;      
                destination.quantity = source.quantity;
                destination.options = source.options;
                destination.hasQuantityLimit = false;
            }
        };
    }

})();